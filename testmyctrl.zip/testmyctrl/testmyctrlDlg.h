
// testmyctrlDlg.h : ͷ�ļ�
//

#pragma once
#include "blvideoctrl1.h"
#include "afxwin.h"


// CtestmyctrlDlg �Ի���
class CtestmyctrlDlg : public CDialogEx
{
// ����
public:
	CtestmyctrlDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_TESTMYCTRL_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;
	bool m_bInit;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	
	/*CBlvideoctrl1 m_ctrlVideo;*/
	afx_msg void OnMove(int x, int y);
	
	CBlvideoctrl1 m_ctrlVideo;
	CButton m_btnPlay;
	afx_msg void OnClose();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	CButton m_btnStop;
	CButton m_btnSet;
};
