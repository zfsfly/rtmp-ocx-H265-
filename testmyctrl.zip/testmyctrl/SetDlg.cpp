// SetDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "testmyctrl.h"
#include "SetDlg.h"
#include "afxdialogex.h"


// CSetDlg �Ի���

IMPLEMENT_DYNAMIC(CSetDlg, CDialogEx)

CSetDlg::CSetDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CSetDlg::IDD, pParent)
{
	m_nSelWinNum= 1;
}

CSetDlg::~CSetDlg()
{
}

void CSetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO1, m_cbWinNums);
}


BEGIN_MESSAGE_MAP(CSetDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &CSetDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CSetDlg ��Ϣ��������


BOOL CSetDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_cbWinNums.AddString("1");
	m_cbWinNums.AddString("2");
	m_cbWinNums.AddString("4");
	m_cbWinNums.AddString("9");
	m_cbWinNums.AddString("16");


	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CSetDlg::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strNum;
	m_cbWinNums.GetWindowText(strNum);
	if (!strNum.IsEmpty())
	{
		m_nSelWinNum =atoi(strNum.GetString());
	}
	CDialogEx::OnOK();
}
