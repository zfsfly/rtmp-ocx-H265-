#pragma once

// ������������� Microsoft Visual C++ ������ IDispatch ��װ��

// ע��: ��Ҫ�޸Ĵ��ļ������ݡ����������
//  Microsoft Visual C++ �������ɣ������޸Ľ������ǡ�

/////////////////////////////////////////////////////////////////////////////
// CBlvideoctrl1 ��װ��

class CBlvideoctrl1 : public CWnd
{
protected:
	DECLARE_DYNCREATE(CBlvideoctrl1)

public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0xC979313E, 0x99A1, 0x467A,{ 0x87, 0x15, 0x85, 0xF9, 0x1A, 0xBF, 0x8F, 0x95 } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect, CWnd* pParentWnd, UINT nID,
		CCreateContext* pContext = nullptr)
	{
		return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID);
	}

	BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd,
		UINT nID, CFile* pPersist = nullptr, BOOL bStorage = FALSE,
		BSTR bstrLicKey = nullptr)
	{
		return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
			pPersist, bStorage, bstrLicKey);
	}

	// ����
public:

	// ����
public:

	void SetWindStyle(unsigned short nStyle)
	{
		static BYTE parms[] = VTS_UI2;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_EMPTY, nullptr, parms, nStyle);
	}
	void StopPlay(long nWindow)
	{
		static BYTE parms[] = VTS_I4;
		InvokeHelper(0x2, DISPATCH_METHOD, VT_EMPTY, nullptr, parms, nWindow);
	}
	short startplayurl(unsigned char * strUrl, short nWindow,  unsigned char * encrypt)
	{
		short result;
		static BYTE parms[] = VTS_PUI1 VTS_I2  VTS_PUI1;
		InvokeHelper(0x3, DISPATCH_METHOD, VT_I2, (void*)&result, parms, strUrl, nWindow,  encrypt);
		return result;
	}
	short SetViewTitle(short nWindow, unsigned char * title)
	{
		short result;
		static BYTE parms[] = VTS_I2 VTS_PUI1;
		InvokeHelper(0x4, DISPATCH_METHOD, VT_I2, (void*)&result, parms, nWindow, title);
		return result;
	}
	void SetPicPath(LPCTSTR strPicPath)
	{
		static BYTE parms[] = VTS_BSTR;
		InvokeHelper(0x6, DISPATCH_METHOD, VT_EMPTY, nullptr, parms, strPicPath);
	}
	long CapturePic(long nWindow)
	{
		long result;
		static BYTE parms[] = VTS_I4;
		InvokeHelper(0x7, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWindow);
		return result;
	}
	long GetActiveWnd()
	{
		long result;
		InvokeHelper(0x8, DISPATCH_METHOD, VT_I4, (void*)&result, nullptr);
		return result;
	}

};
