// SetUrlDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "testmyctrl.h"
#include "SetUrlDlg.h"
#include "afxdialogex.h"


// CSetUrlDlg �Ի���

IMPLEMENT_DYNAMIC(CSetUrlDlg, CDialogEx)

CSetUrlDlg::CSetUrlDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CSetUrlDlg::IDD, pParent)
	, m_strUrl(_T(""))
{

}

CSetUrlDlg::~CSetUrlDlg()
{
}

void CSetUrlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSetUrlDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &CSetUrlDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CSetUrlDlg ��Ϣ��������


void CSetUrlDlg::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	GetDlgItem(IDC_EDIT1)->GetWindowText(m_strUrl);
	CDialogEx::OnOK();
}
